import model.Player;

import java.util.ArrayList;

public class Main {

    public static Controller controller = new Controller();

    public static void main(String[] args) {
        //Menus
    }
}