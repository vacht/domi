package model;

public enum PlayerPosition {
    GOALKEEPER, DEFENSE, MIDFIELDER, FORWARDER
}
