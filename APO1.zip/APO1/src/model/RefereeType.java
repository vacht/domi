package model;

enum RefereeType {
    CENTRAL, LINE_ASSISTANT, ASSISTANT, VAR
}
